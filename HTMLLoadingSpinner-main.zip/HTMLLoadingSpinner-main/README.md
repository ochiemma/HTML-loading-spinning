This is my first HTML and CSS project creating a loading animation. Hope you like it!
